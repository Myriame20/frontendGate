# 🎯 PROMPT COMPLET POUR CLAUDE IA - CONSTRUCTION DU BACKEND EDUGATE

## 📋 CONTEXTE DU PROJET

Tu vas construire le backend complet pour **EduGate**, une plateforme SaaS de gestion des inscriptions scolaires qui connecte les écoles et les parents.

Le frontend est déjà développé en React/TypeScript. Tu dois créer un backend qui reproduit exactement la logique métier implémentée dans le frontend.

---

## 🏗️ ARCHITECTURE GLOBALE

### Stack Technique Recommandée
- **Backend** : Node.js + Express.js ou NestJS
- **Base de données** : PostgreSQL (recommandé) ou MongoDB
- **ORM** : Prisma (PostgreSQL) ou Mongoose (MongoDB)
- **Authentification** : JWT + bcrypt
- **Validation** : Joi ou Zod
- **Upload fichiers** : Multer + AWS S3 ou Cloudinary
- **Emails** : Nodemailer + SendGrid/Mailgun
- **Documentation API** : Swagger/OpenAPI

### Structure du Projet
```
backend/
├── src/
│   ├── config/
│   │   ├── database.js
│   │   └── env.js
│   ├── models/
│   │   ├── School.js
│   │   ├── SchoolAdmin.js
│   │   ├── Parent.js
│   │   ├── Application.js
│   │   ├── Message.js
│   │   └── AcademicYear.js
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── schoolController.js
│   │   ├── parentController.js
│   │   ├── applicationController.js
│   │   └── adminController.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── schools.js
│   │   ├── parents.js
│   │   ├── applications.js
│   │   └── admin.js
│   ├── middleware/
│   │   ├── auth.js
│   │   ├── validation.js
│   │   └── error.js
│   ├── services/
│   │   ├── emailService.js
│   │   ├── notificationService.js
│   │   └── fileService.js
│   ├── utils/
│   │   ├── validators.js
│   │   └── helpers.js
│   └── app.js
├── .env
├── package.json
└── README.md
```

---

## 🗄️ SCHÉMA DE BASE DE DONNÉES

### Table: schools
```sql
CREATE TABLE schools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  logo VARCHAR(500),
  cover_image VARCHAR(500),
  type VARCHAR(50) NOT NULL CHECK (type IN ('Maternelle', 'Primaire', 'Secondaire', 'Complexe')),
  address TEXT NOT NULL,
  city VARCHAR(100) NOT NULL,
  province VARCHAR(100),
  phone VARCHAR(20),
  email VARCHAR(255) NOT NULL UNIQUE,
  website VARCHAR(255),
  description TEXT,
  founded INTEGER,
  students INTEGER DEFAULT 0,
  teachers INTEGER DEFAULT 0,
  programs TEXT[] DEFAULT '{}',
  languages TEXT[] DEFAULT '{"Français"}',
  fees JSONB DEFAULT '[]',
  rating DECIMAL(2,1) DEFAULT 0.0,
  gallery TEXT[] DEFAULT '{}',
  videos JSONB DEFAULT '[]',
  features TEXT[] DEFAULT '{}',
  admin_email VARCHAR(255) NOT NULL,
  enrollment_open BOOLEAN DEFAULT false,
  is_visible BOOLEAN DEFAULT false,
  is_verified BOOLEAN DEFAULT false,
  verification_status VARCHAR(20) DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
  uploaded_media JSONB DEFAULT '[]',
  admission_requirements TEXT[] DEFAULT '{}',
  total_places INTEGER DEFAULT 0,
  available_places INTEGER DEFAULT 0,
  academic_year VARCHAR(20) DEFAULT '2025-2026',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: school_admins
```sql
CREATE TABLE school_admins (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('super_admin', 'admin', 'secretary', 'communication')),
  permissions JSONB DEFAULT '["all"]',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: parents
```sql
CREATE TABLE parents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  children JSONB DEFAULT '[]',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: applications
```sql
CREATE TABLE applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  child_name VARCHAR(255) NOT NULL,
  child_dob DATE NOT NULL,
  grade VARCHAR(100) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'review', 'approved', 'rejected')),
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  viewed_by_school BOOLEAN DEFAULT false,
  documents JSONB DEFAULT '[]',
  notes TEXT,
  academic_year VARCHAR(20) DEFAULT '2025-2026',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: messages
```sql
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sender_id UUID NOT NULL,
  sender_type VARCHAR(20) NOT NULL CHECK (sender_type IN ('parent', 'school')),
  receiver_id UUID NOT NULL,
  receiver_type VARCHAR(20) NOT NULL CHECK (receiver_type IN ('parent', 'school')),
  content TEXT NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  read BOOLEAN DEFAULT false,
  application_id UUID REFERENCES applications(id) ON DELETE SET NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: appointments
```sql
CREATE TABLE appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id UUID NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  time TIME NOT NULL,
  type VARCHAR(100) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled')),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: academic_years
```sql
CREATE TABLE academic_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_id UUID NOT NULL REFERENCES schools(id) ON DELETE CASCADE,
  year VARCHAR(20) NOT NULL,
  total_students INTEGER DEFAULT 0,
  students_by_class JSONB DEFAULT '{}',
  results JSONB DEFAULT '[]',
  is_open BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(school_id, year)
);
```

---

## 🔐 AUTHENTIFICATION ET AUTORISATION

### Système d'Authentification

**Pour les Parents :**
- Inscription avec email, mot de passe, prénom, nom, téléphone
- Connexion avec email + mot de passe
- JWT token avec payload : `{ id, type: 'parent', email }`
- Durée du token : 7 jours

**Pour les Écoles :**
- Inscription via le processus d'onboarding (crée école + admin)
- Connexion avec email + mot de passe
- JWT token avec payload : `{ id, type: 'school', schoolId, role, email }`
- Durée du token : 7 jours

**Pour l'Admin Plateforme :**
- Compte créé manuellement dans la base
- Connexion avec email + mot de passe
- JWT token avec payload : `{ id, type: 'platform_admin', email }`
- Durée du token : 7 jours

### Middleware d'Authentification

```javascript
// middleware/auth.js
const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token d\'authentification requis' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token invalide ou expiré' });
    }
    req.user = user;
    next();
  });
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.type)) {
      return res.status(403).json({ error: 'Accès non autorisé' });
    }
    next();
  };
};

const requireSchoolAccess = async (req, res, next) => {
  if (req.user.type !== 'school') {
    return res.status(403).json({ error: 'Accès réservé aux écoles' });
  }
  
  const schoolId = req.params.schoolId || req.body.schoolId;
  if (schoolId && req.user.schoolId !== schoolId) {
    return res.status(403).json({ error: 'Accès non autorisé à cette école' });
  }
  
  next();
};

module.exports = { authenticateToken, requireRole, requireSchoolAccess };
```

---

## 📡 ENDPOINTS API

### 1. AUTHENTIFICATION

#### POST /api/auth/parent/register
**Description** : Inscription d'un parent

**Request Body :**
```json
{
  "firstName": "Marie",
  "lastName": "Ngozi",
  "email": "marie@example.com",
  "phone": "+241 01 23 45 67",
  "password": "password123"
}
```

**Response (201) :**
```json
{
  "message": "Compte parent créé avec succès",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "parent": {
    "id": "uuid",
    "firstName": "Marie",
    "lastName": "Ngozi",
    "email": "marie@example.com",
    "phone": "+241 01 23 45 67"
  }
}
```

**Règles métier :**
- Email doit être unique
- Mot de passe minimum 6 caractères
- Hasher le mot de passe avec bcrypt (10 rounds)

---

#### POST /api/auth/parent/login
**Description** : Connexion d'un parent

**Request Body :**
```json
{
  "email": "marie@example.com",
  "password": "password123"
}
```

**Response (200) :**
```json
{
  "message": "Connexion réussie",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "parent": {
    "id": "uuid",
    "firstName": "Marie",
    "lastName": "Ngozi",
    "email": "marie@example.com"
  }
}
```

---

#### POST /api/auth/school/login
**Description** : Connexion d'une école

**Request Body :**
```json
{
  "email": "admin@ecole.com",
  "password": "password123"
}
```

**Response (200) :**
```json
{
  "message": "Connexion réussie",
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "admin": {
    "id": "uuid",
    "name": "Jean Directeur",
    "email": "admin@ecole.com",
    "schoolId": "uuid",
    "role": "super_admin"
  }
}
```

---

### 2. ÉCOLES

#### POST /api/schools/onboarding
**Description** : Inscription d'une nouvelle école (crée école + admin)

**Request Body :**
```json
{
  "schoolName": "Lycée Léon Mba",
  "schoolType": "Secondaire",
  "email": "contact@lycee.com",
  "phone": "+241 01 76 00 00",
  "city": "Libreville",
  "address": "Boulevard Triomphal",
  "description": "Excellence éducative depuis 1960",
  "adminName": "Jean Directeur",
  "adminEmail": "admin@lycee.com",
  "adminPassword": "password123"
}
```

**Response (201) :**
```json
{
  "message": "École créée avec succès, en attente de validation",
  "school": {
    "id": "uuid",
    "name": "Lycée Léon Mba",
    "verificationStatus": "pending",
    "isVisible": false,
    "isVerified": false
  },
  "admin": {
    "id": "uuid",
    "name": "Jean Directeur",
    "email": "admin@lycee.com"
  }
}
```

**Règles métier :**
- Créer l'école avec `verificationStatus: 'pending'`
- Créer l'école avec `isVisible: false`
- Créer l'école avec `isVerified: false`
- Créer l'admin avec `role: 'super_admin'`
- Hasher le mot de passe de l'admin
- Email de l'école et de l'admin doivent être uniques

---

#### GET /api/schools
**Description** : Liste des écoles vérifiées et visibles

**Query Params :**
- `search` : Recherche par nom ou ville
- `type` : Filtre par type
- `city` : Filtre par ville

**Response (200) :**
```json
{
  "schools": [
    {
      "id": "uuid",
      "name": "Lycée Léon Mba",
      "logo": "🏫",
      "coverImage": "https://...",
      "type": "Secondaire",
      "city": "Libreville",
      "rating": 4.8,
      "students": 1200,
      "enrollmentOpen": true,
      "availablePlaces": 23,
      "description": "..."
    }
  ],
  "total": 3
}
```

**Règles métier :**
- Retourner uniquement les écoles avec `isVisible: true` ET `isVerified: true`
- Appliquer les filtres si fournis

---

#### GET /api/schools/:id
**Description** : Détails d'une école

**Response (200) :**
```json
{
  "school": {
    "id": "uuid",
    "name": "Lycée Léon Mba",
    "logo": "🏫",
    "coverImage": "https://...",
    "type": "Secondaire",
    "address": "Boulevard Triomphal, Libreville",
    "city": "Libreville",
    "phone": "+241 01 76 00 00",
    "email": "contact@lycee.com",
    "description": "...",
    "founded": 1960,
    "students": 1200,
    "teachers": 85,
    "programs": ["Baccalauréat Général", "Baccalauréat Technique"],
    "languages": ["Français", "Anglais"],
    "fees": [
      { "label": "Inscription", "amount": "150 000 FCFA" },
      { "label": "Scolarité annuelle", "amount": "800 000 FCFA" }
    ],
    "rating": 4.8,
    "features": ["Laboratoire de sciences", "Bibliothèque numérique"],
    "admissionRequirements": ["Bulletins des 2 dernières années", "Acte de naissance"],
    "totalPlaces": 100,
    "availablePlaces": 23,
    "enrollmentOpen": true,
    "academicYear": "2025-2026"
  }
}
```

**Règles métier :**
- Retourner uniquement si `isVisible: true` ET `isVerified: true`

---

#### PUT /api/schools/:id
**Description** : Modifier les informations de l'école

**Headers :** `Authorization: Bearer <token>`

**Request Body :**
```json
{
  "description": "Nouvelle description",
  "programs": ["Programme 1", "Programme 2"],
  "totalPlaces": 150
}
```

**Response (200) :**
```json
{
  "message": "École mise à jour avec succès",
  "school": { ... }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin de cette école
- Vérifier que l'école est vérifiée

---

### 3. CANDIDATURES

#### POST /api/applications
**Description** : Soumettre une candidature

**Headers :** `Authorization: Bearer <token>` (parent)

**Request Body :**
```json
{
  "schoolId": "uuid",
  "childName": "Emma Mba",
  "childDob": "2010-05-15",
  "grade": "6ème",
  "notes": "Informations complémentaires"
}
```

**Response (201) :**
```json
{
  "message": "Candidature soumise avec succès",
  "application": {
    "id": "uuid",
    "parentId": "uuid",
    "schoolId": "uuid",
    "childName": "Emma Mba",
    "childDob": "2010-05-15",
    "grade": "6ème",
    "status": "pending",
    "submittedAt": "2026-01-15T10:00:00Z",
    "lastModifiedAt": "2026-01-15T10:00:00Z",
    "viewedBySchool": false,
    "notes": "Informations complémentaires",
    "academicYear": "2025-2026"
  }
}
```

**Règles métier :**
- Vérifier que l'école existe et est vérifiée
- Vérifier que `availablePlaces > 0`
- Vérifier que `enrollmentOpen: true`
- Définir `status: 'pending'`
- Définir `viewedBySchool: false`
- Définir `academicYear` depuis l'école

---

#### GET /api/applications
**Description** : Liste des candidatures du parent connecté

**Headers :** `Authorization: Bearer <token>` (parent)

**Response (200) :**
```json
{
  "applications": [
    {
      "id": "uuid",
      "schoolId": "uuid",
      "schoolName": "Lycée Léon Mba",
      "childName": "Emma Mba",
      "childDob": "2010-05-15",
      "grade": "6ème",
      "status": "pending",
      "submittedAt": "2026-01-15T10:00:00Z",
      "lastModifiedAt": "2026-01-15T10:00:00Z",
      "viewedBySchool": false,
      "notes": "..."
    }
  ]
}
```

**Règles métier :**
- Retourner uniquement les candidatures du parent connecté
- Inclure le nom de l'école

---

#### PUT /api/applications/:id
**Description** : Modifier une candidature

**Headers :** `Authorization: Bearer <token>` (parent)

**Request Body :**
```json
{
  "childName": "Emma Ngozi",
  "childDob": "2010-05-15",
  "notes": "Nouvelles notes"
}
```

**Response (200) :**
```json
{
  "message": "Candidature mise à jour",
  "application": { ... }
}
```

**Règles métier :**
- Vérifier que la candidature appartient au parent connecté
- **CRITIQUE** : Vérifier que `viewedBySchool: false` ET `status: 'pending'`
- Si ces conditions ne sont pas remplies, retourner erreur 403
- Mettre à jour `lastModifiedAt`

---

#### GET /api/schools/:schoolId/applications
**Description** : Liste des candidatures pour une école

**Headers :** `Authorization: Bearer <token>` (école)

**Response (200) :**
```json
{
  "applications": [
    {
      "id": "uuid",
      "parentId": "uuid",
      "childName": "Emma Mba",
      "childDob": "2010-05-15",
      "grade": "6ème",
      "status": "pending",
      "submittedAt": "2026-01-15T10:00:00Z",
      "lastModifiedAt": "2026-01-15T10:00:00Z",
      "viewedBySchool": false,
      "notes": "..."
    }
  ]
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin de cette école
- Retourner uniquement les candidatures pour cette école

---

#### GET /api/schools/:schoolId/applications/:id
**Description** : Détails d'une candidature (consultation)

**Headers :** `Authorization: Bearer <token>` (école)

**Response (200) :**
```json
{
  "application": {
    "id": "uuid",
    "childName": "Emma Mba",
    "childDob": "2010-05-15",
    "grade": "6ème",
    "status": "pending",
    "submittedAt": "2026-01-15T10:00:00Z",
    "lastModifiedAt": "2026-01-15T10:00:00Z",
    "viewedBySchool": true,
    "notes": "..."
  }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin de cette école
- **CRITIQUE** : Mettre à jour `viewedBySchool: true` automatiquement
- Retourner tous les détails de la candidature

---

#### PUT /api/schools/:schoolId/applications/:id/status
**Description** : Mettre à jour le statut d'une candidature

**Headers :** `Authorization: Bearer <token>` (école)

**Request Body :**
```json
{
  "status": "approved"
}
```

**Response (200) :**
```json
{
  "message": "Statut mis à jour",
  "application": { ... }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin de cette école
- Mettre à jour `viewedBySchool: true`
- **CRITIQUE** : Si `status: 'approved'` :
  - Vérifier que `availablePlaces > 0`
  - Décrémenter `availablePlaces` de 1
  - Si `availablePlaces` atteint 0, définir `enrollmentOpen: false`
- Mettre à jour le statut de la candidature

---

### 4. ADMIN PLATEFORME

#### GET /api/admin/schools
**Description** : Liste de toutes les écoles (admin plateforme)

**Headers :** `Authorization: Bearer <token>` (platform_admin)

**Query Params :**
- `status` : pending, verified, rejected

**Response (200) :**
```json
{
  "schools": [
    {
      "id": "uuid",
      "name": "Lycée Léon Mba",
      "city": "Libreville",
      "type": "Secondaire",
      "email": "contact@lycee.com",
      "verificationStatus": "pending",
      "isVisible": false,
      "isVerified": false,
      "createdAt": "2026-01-15T10:00:00Z"
    }
  ],
  "stats": {
    "pending": 5,
    "verified": 10,
    "rejected": 2,
    "total": 17
  }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin plateforme
- Retourner toutes les écoles (même non vérifiées)
- Inclure les statistiques

---

#### PUT /api/admin/schools/:id/verify
**Description** : Valider une école

**Headers :** `Authorization: Bearer <token>` (platform_admin)

**Response (200) :**
```json
{
  "message": "École validée avec succès",
  "school": {
    "id": "uuid",
    "name": "Lycée Léon Mba",
    "verificationStatus": "verified",
    "isVisible": true,
    "isVerified": true
  }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin plateforme
- Définir `verificationStatus: 'verified'`
- Définir `isVisible: true`
- Définir `isVerified: true`
- Envoyer un email de notification à l'école

---

#### PUT /api/admin/schools/:id/reject
**Description** : Rejeter une école

**Headers :** `Authorization: Bearer <token>` (platform_admin)

**Request Body :**
```json
{
  "reason": "Informations incomplètes"
}
```

**Response (200) :**
```json
{
  "message": "École rejetée",
  "school": {
    "id": "uuid",
    "name": "Lycée Léon Mba",
    "verificationStatus": "rejected",
    "isVisible": false,
    "isVerified": false
  }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin plateforme
- Définir `verificationStatus: 'rejected'`
- Définir `isVisible: false`
- Définir `isVerified: false`
- Envoyer un email de notification à l'école avec la raison

---

### 5. MESSAGES

#### POST /api/messages
**Description** : Envoyer un message

**Headers :** `Authorization: Bearer <token>`

**Request Body :**
```json
{
  "receiverId": "uuid",
  "receiverType": "school",
  "content": "Bonjour, j'ai une question...",
  "applicationId": "uuid"
}
```

**Response (201) :**
```json
{
  "message": "Message envoyé",
  "message": {
    "id": "uuid",
    "senderId": "uuid",
    "senderType": "parent",
    "receiverId": "uuid",
    "receiverType": "school",
    "content": "Bonjour, j'ai une question...",
    "timestamp": "2026-01-15T10:00:00Z",
    "read": false,
    "applicationId": "uuid"
  }
}
```

---

#### GET /api/messages
**Description** : Liste des messages

**Headers :** `Authorization: Bearer <token>`

**Response (200) :**
```json
{
  "messages": [
    {
      "id": "uuid",
      "senderId": "uuid",
      "senderType": "parent",
      "senderName": "Marie Ngozi",
      "content": "Bonjour...",
      "timestamp": "2026-01-15T10:00:00Z",
      "read": false
    }
  ]
}
```

**Règles métier :**
- Retourner les messages envoyés ou reçus par l'utilisateur connecté
- Inclure le nom de l'expéditeur

---

#### PUT /api/messages/:id/read
**Description** : Marquer un message comme lu

**Headers :** `Authorization: Bearer <token>`

**Response (200) :**
```json
{
  "message": "Message marqué comme lu"
}
```

**Règles métier :**
- Vérifier que l'utilisateur est le destinataire
- Définir `read: true`

---

### 6. RENDEZ-VOUS

#### POST /api/appointments
**Description** : Créer un rendez-vous

**Headers :** `Authorization: Bearer <token>` (parent)

**Request Body :**
```json
{
  "schoolId": "uuid",
  "date": "2026-01-20",
  "time": "14:00",
  "type": "Visite",
  "notes": "Je souhaite visiter l'école"
}
```

**Response (201) :**
```json
{
  "message": "Rendez-vous créé",
  "appointment": {
    "id": "uuid",
    "parentId": "uuid",
    "schoolId": "uuid",
    "date": "2026-01-20",
    "time": "14:00",
    "type": "Visite",
    "status": "pending",
    "notes": "Je souhaite visiter l'école"
  }
}
```

---

#### PUT /api/appointments/:id/status
**Description** : Mettre à jour le statut d'un rendez-vous

**Headers :** `Authorization: Bearer <token>` (école)

**Request Body :**
```json
{
  "status": "confirmed"
}
```

**Response (200) :**
```json
{
  "message": "Statut mis à jour",
  "appointment": { ... }
}
```

**Règles métier :**
- Vérifier que l'utilisateur est un admin de l'école
- Mettre à jour le statut

---

## 🔔 SYSTÈME DE NOTIFICATIONS

### Emails à Envoyer

1. **Inscription école réussie**
   - Destinataire : Admin de l'école
   - Sujet : "Votre école a été inscrite avec succès"
   - Contenu : Identifiants de connexion, délai de validation

2. **École validée**
   - Destinataire : Admin de l'école
   - Sujet : "Votre école a été validée"
   - Contenu : Lien vers le dashboard

3. **École rejetée**
   - Destinataire : Admin de l'école
   - Sujet : "Votre inscription a été rejetée"
   - Contenu : Raison du rejet, lien pour resoumettre

4. **Nouvelle candidature**
   - Destinataire : Admin de l'école
   - Sujet : "Nouvelle candidature reçue"
   - Contenu : Détails de la candidature

5. **Candidature approuvée**
   - Destinataire : Parent
   - Sujet : "Votre candidature a été approuvée"
   - Contenu : Détails de l'école, prochaines étapes

6. **Candidature rejetée**
   - Destinataire : Parent
   - Sujet : "Votre candidature a été rejetée"
   - Contenu : Raison (si fournie)

7. **Nouveau message**
   - Destinataire : Parent ou École
   - Sujet : "Nouveau message reçu"
   - Contenu : Extrait du message

8. **Rendez-vous confirmé**
   - Destinataire : Parent
   - Sujet : "Votre rendez-vous a été confirmé"
   - Contenu : Date, heure, lieu

### Service Email

```javascript
// services/emailService.js
const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  secure: true,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

const sendEmail = async (to, subject, html) => {
  try {
    await transporter.sendMail({
      from: `"EduGate" <${process.env.SMTP_FROM}>`,
      to,
      subject,
      html
    });
    console.log(`Email envoyé à ${to}`);
  } catch (error) {
    console.error('Erreur envoi email:', error);
  }
};

module.exports = { sendEmail };
```

---

## 📤 UPLOAD DE FICHIERS

### Configuration Multer

```javascript
// middleware/upload.js
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb(new Error('Type de fichier non autorisé'));
  }
};

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter
});

module.exports = upload;
```

### Endpoints d'Upload

#### POST /api/applications/:id/documents
**Description** : Upload de documents pour une candidature

**Headers :** 
- `Authorization: Bearer <token>` (parent)
- `Content-Type: multipart/form-data`

**Request Body :**
- `documents` : Fichiers (max 5 fichiers, 10MB chacun)

**Response (200) :**
```json
{
  "message": "Documents uploadés",
  "documents": [
    {
      "name": "acte-naissance.pdf",
      "type": "application/pdf",
      "url": "/uploads/acte-naissance-123456.pdf",
      "uploadedAt": "2026-01-15T10:00:00Z"
    }
  ]
}
```

**Règles métier :**
- Vérifier que la candidature appartient au parent
- Vérifier que `viewedBySchool: false`
- Stocker les fichiers dans `uploads/`
- Mettre à jour le champ `documents` de la candidature

---

## 🔒 SÉCURITÉ

### 1. Validation des Entrées

```javascript
// utils/validators.js
const Joi = require('joi');

const registerParentSchema = Joi.object({
  firstName: Joi.string().min(2).max(100).required(),
  lastName: Joi.string().min(2).max(100).required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^\+?[0-9]{10,15}$/).required(),
  password: Joi.string().min(6).required()
});

const schoolOnboardingSchema = Joi.object({
  schoolName: Joi.string().min(3).max(255).required(),
  schoolType: Joi.string().valid('Maternelle', 'Primaire', 'Secondaire', 'Complexe').required(),
  email: Joi.string().email().required(),
  phone: Joi.string().pattern(/^\+?[0-9]{10,15}$/).required(),
  city: Joi.string().min(2).max(100).required(),
  address: Joi.string().min(5).required(),
  description: Joi.string().min(10).required(),
  adminName: Joi.string().min(3).max(255).required(),
  adminEmail: Joi.string().email().required(),
  adminPassword: Joi.string().min(6).required()
});

const applicationSchema = Joi.object({
  schoolId: Joi.string().uuid().required(),
  childName: Joi.string().min(3).max(255).required(),
  childDob: Joi.date().iso().required(),
  grade: Joi.string().min(2).max(100).required(),
  notes: Joi.string().allow('').optional()
});

module.exports = { registerParentSchema, schoolOnboardingSchema, applicationSchema };
```

### 2. Rate Limiting

```javascript
// middleware/rateLimit.js
const rateLimit = require('express-rate-limit');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 tentatives
  message: 'Trop de tentatives, veuillez réessayer dans 15 minutes'
});

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100, // 100 requêtes
  message: 'Trop de requêtes, veuillez réessayer plus tard'
});

module.exports = { authLimiter, apiLimiter };
```

### 3. Protection CSRF

```javascript
const helmet = require('helmet');
const cors = require('cors');

app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true
}));
```

---

## 📦 VARIABLES D'ENVIRONNEMENT

```env
# .env
NODE_ENV=development
PORT=5000

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/edugate

# JWT
JWT_SECRET=your-super-secret-key-change-in-production
JWT_EXPIRES_IN=7d

# Email (SendGrid)
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
SMTP_FROM=noreply@edugate.com

# File Upload
UPLOAD_DIR=./uploads
MAX_FILE_SIZE=10485760

# Frontend
FRONTEND_URL=http://localhost:5173

# AWS S3 (optionnel)
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_REGION=us-east-1
AWS_S3_BUCKET=edugate-uploads
```

---

## 🧪 TESTS

### Tests Unitaires (Jest)

```javascript
// tests/application.test.js
const request = require('supertest');
const app = require('../src/app');

describe('Application API', () => {
  let token;
  let schoolId;

  beforeAll(async () => {
    // Créer un parent et se connecter
    const parentRes = await request(app)
      .post('/api/auth/parent/register')
      .send({
        firstName: 'Test',
        lastName: 'Parent',
        email: 'test@example.com',
        phone: '+24101234567',
        password: 'password123'
      });
    token = parentRes.body.token;

    // Récupérer une école
    const schoolsRes = await request(app).get('/api/schools');
    schoolId = schoolsRes.body.schools[0].id;
  });

  describe('POST /api/applications', () => {
    it('should create application when places available', async () => {
      const res = await request(app)
        .post('/api/applications')
        .set('Authorization', `Bearer ${token}`)
        .send({
          schoolId,
          childName: 'Emma Test',
          childDob: '2010-05-15',
          grade: '6ème',
          notes: 'Test'
        });

      expect(res.statusCode).toBe(201);
      expect(res.body.application.status).toBe('pending');
      expect(res.body.application.viewedBySchool).toBe(false);
    });

    it('should reject application when no places available', async () => {
      // Mock une école avec 0 places
      // ...
    });
  });

  describe('PUT /api/applications/:id', () => {
    it('should allow modification when not viewed by school', async () => {
      // Créer une candidature
      // ...
      
      const res = await request(app)
        .put(`/api/applications/${applicationId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          childName: 'Emma Updated'
        });

      expect(res.statusCode).toBe(200);
    });

    it('should reject modification when viewed by school', async () => {
      // Simuler une consultation par l'école
      // ...
      
      const res = await request(app)
        .put(`/api/applications/${applicationId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          childName: 'Emma Updated'
        });

      expect(res.statusCode).toBe(403);
    });
  });
});
```

---

## 🚀 DÉPLOIEMENT

### Docker

```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 5000

CMD ["node", "src/app.js"]
```

```yaml
# docker-compose.yml
version: '3.8'

services:
  backend:
    build: .
    ports:
      - "5000:5000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://postgres:password@db:5432/edugate
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=edugate
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

---

## 📋 CHECKLIST D'IMPLÉMENTATION

### Phase 1 : Fondations
- [ ] Initialiser le projet Node.js
- [ ] Configurer PostgreSQL
- [ ] Créer le schéma de base de données
- [ ] Configurer Prisma/ORM
- [ ] Mettre en place l'authentification JWT
- [ ] Créer les modèles de données

### Phase 2 : API Authentification
- [ ] POST /api/auth/parent/register
- [ ] POST /api/auth/parent/login
- [ ] POST /api/auth/school/login
- [ ] Middleware d'authentification
- [ ] Middleware de validation des rôles

### Phase 3 : API Écoles
- [ ] POST /api/schools/onboarding
- [ ] GET /api/schools
- [ ] GET /api/schools/:id
- [ ] PUT /api/schools/:id
- [ ] Logique de validation des écoles

### Phase 4 : API Candidatures
- [ ] POST /api/applications
- [ ] GET /api/applications
- [ ] PUT /api/applications/:id
- [ ] GET /api/schools/:schoolId/applications
- [ ] GET /api/schools/:schoolId/applications/:id
- [ ] PUT /api/schools/:schoolId/applications/:id/status
- [ ] **Logique critique** : Mise à jour des places

### Phase 5 : API Admin
- [ ] GET /api/admin/schools
- [ ] PUT /api/admin/schools/:id/verify
- [ ] PUT /api/admin/schools/:id/reject
- [ ] Statistiques

### Phase 6 : API Messages & RDV
- [ ] POST /api/messages
- [ ] GET /api/messages
- [ ] PUT /api/messages/:id/read
- [ ] POST /api/appointments
- [ ] PUT /api/appointments/:id/status

### Phase 7 : Upload & Notifications
- [ ] Configuration Multer
- [ ] POST /api/applications/:id/documents
- [ ] Service d'envoi d'emails
- [ ] Templates d'emails
- [ ] Intégration des notifications

### Phase 8 : Sécurité & Tests
- [ ] Validation des entrées (Joi)
- [ ] Rate limiting
- [ ] Protection CSRF
- [ ] Tests unitaires
- [ ] Tests d'intégration

### Phase 9 : Déploiement
- [ ] Dockerfile
- [ ] docker-compose.yml
- [ ] Configuration production
- [ ] Variables d'environnement
- [ ] Documentation API (Swagger)

---

## 🎯 POINTS CRITIQUES À RESPECTER

### 1. Gestion des Places
**RÈGLE ABSOLUE** : Lors de l'approbation d'une candidature, décrémenter `availablePlaces` de 1. Si `availablePlaces` atteint 0, définir `enrollmentOpen: false`.

### 2. Modification des Candidatures
**RÈGLE ABSOLUE** : Un parent ne peut modifier sa candidature QUE si `viewedBySchool: false` ET `status: 'pending'`. Sinon, retourner erreur 403.

### 3. Consultation des Candidatures
**RÈGLE ABSOLUE** : Lorsqu'une école consulte une candidature (GET /api/schools/:schoolId/applications/:id), mettre automatiquement `viewedBySchool: true`.

### 4. Validation des Écoles
**RÈGLE ABSOLUE** : Une école n'est visible publiquement QUE si `isVisible: true` ET `isVerified: true`.

### 5. Isolation des Données
**RÈGLE ABSOLUE** : Une école ne peut voir/modifier QUE ses propres candidatures, messages, rendez-vous. Jamais ceux d'une autre école.

---

## 📞 CONTACT

Pour toute question sur l'implémentation :
- Documentation frontend : Voir les fichiers `.md` dans le projet frontend
- Schéma de base de données : Voir section ci-dessus
- Endpoints API : Voir section ci-dessus
- Règles métier : Voir section "POINTS CRITIQUES"

---

**Ce prompt contient TOUTES les informations nécessaires pour construire le backend complet d'EduGate. Implémente chaque endpoint en respectant scrupuleusement les règles métier définies.**
