#!/bin/bash

# Script pour lister tous les fichiers du projet EduGate
# Utilisez ce script pour voir la structure complète

echo "📁 Structure du projet EduGate"
echo "================================"
echo ""

echo "📄 Fichiers de configuration"
echo "----------------------------"
ls -la | grep -E "\.(json|js|html|ts)$"
echo ""

echo "📂 Dossier src/"
echo "----------------"
find src -type f -name "*.tsx" -o -name "*.ts" -o -name "*.css" | sort
echo ""

echo "📚 Documentation"
echo "----------------"
ls -la *.md
echo ""

echo "✅ Total des fichiers"
echo "---------------------"
find . -type f -not -path "./node_modules/*" -not -path "./dist/*" -not -path "./.git/*" | wc -l
echo "fichiers dans le projet"
echo ""

echo "🚀 Pour récupérer le code :"
echo "1. Consultez GUIDE_RECOVERY.md pour les instructions complètes"
echo "2. Ou copiez manuellement chaque fichier listé ci-dessus"
